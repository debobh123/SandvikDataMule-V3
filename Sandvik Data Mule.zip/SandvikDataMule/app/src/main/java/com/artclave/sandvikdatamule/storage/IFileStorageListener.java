package com.artclave.sandvikdatamule.storage;

public interface IFileStorageListener {
    void onMachineMetaDataChanged(String machineSerial);
}

